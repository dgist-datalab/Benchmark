create table s_catalog_page as
(select CP_CATALOG_NUMBER cpag_catalog_number
       ,CP_CATALOG_PAGE_NUMBER cpag_catalog_page_number 
       ,CP_DEPARTMENT cpag_department
